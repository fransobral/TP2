# TP2
Trabajo grupal para la catedra Costa utilizando las Apis de gmail y google drive.
La idea es poder crear un programa de python con el cual podamos administrar nuestros archivos de google drive (crear, descargar, eliminar, etc) y que a la vez podamos tambien leer y administrar nuestros mails del servicio de gmail.
